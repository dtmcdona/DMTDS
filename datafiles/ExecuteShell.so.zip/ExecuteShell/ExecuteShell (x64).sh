cd "${0%/*}"
g++ -c -std=c++17 "ExecuteShell.cpp" -fPIC -m64
g++ "ExecuteShell.o" -o "ExecuteShell (x64)/ExecuteShell.so" -shared -fPIC -m64
