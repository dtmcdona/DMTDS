cd "${0%/*}"
g++ -c -std=c++17 "ExecuteShell.cpp" -fPIC -m32
g++ "ExecuteShell.o" -o "ExecuteShell (x86)/ExecuteShell.so" -shared -fPIC -m32
