#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string>

using std::string;

extern "C"
{
    double ExecuteShell(char *fname, double wait)
    {
        string strFName = fname;

        for (size_t i = 0; i < strFName.length(); i++)
            if (strFName[i] == '\n')
                return 0;

        if (system(NULL))
        {
            if ((bool)wait == true)
            {
                system(fname);
            }
            else
            {
                int fork_rv = fork();

                if (fork_rv == 0)
                {
                    fork_rv = fork();
                    if (fork_rv == 0)
                    {
                        system(fname);
                        _exit(1);
                    }
                    else if (fork_rv == -1)
                    {
                        _exit(2);
                    }

                    _exit(0);
                }
                else if (fork_rv != -1)
                {
                    int status;
                    waitpid(fork_rv, &status, 0);
                }
            }
        }

        return 0;
    }
}
